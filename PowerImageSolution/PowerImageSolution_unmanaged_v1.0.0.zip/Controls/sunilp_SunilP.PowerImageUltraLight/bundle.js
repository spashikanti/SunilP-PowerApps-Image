/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PowerImageUltraLight/index.ts"
/*!***************************************!*\
  !*** ./PowerImageUltraLight/index.ts ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PowerImageUltraLight: () => (/* binding */ PowerImageUltraLight)\n/* harmony export */ });\n// Define the priority ranking\nvar PRIORITY_MAP = {\n  'image/avif': 1,\n  'image/webp': 2,\n  'image/png': 3,\n  'image/jpeg': 4,\n  'image/gif': 5\n};\nclass PowerImageUltraLight {\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n  }\n  // Helper to get image type from URL extension\n  getMimeType(url) {\n    var _a;\n    var extension = (_a = url.split('.').pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase();\n    switch (extension) {\n      case 'avif':\n        return 'image/avif';\n      case 'webp':\n        return 'image/webp';\n      case 'png':\n        return 'image/png';\n      case 'gif':\n        return 'image/gif';\n      default:\n        return 'image/jpeg';\n    }\n  }\n  updateView(context) {\n    var {\n      AVIFSource,\n      WebPSource,\n      JPEGSource,\n      AltText\n    } = context.parameters;\n    // 1. Get allocated dimensions from the Power Apps container\n    var ImageWidth = context.mode.allocatedWidth !== -1 ? \"\".concat(context.mode.allocatedWidth, \"px\") : \"100%\";\n    var ImageHeight = context.mode.allocatedHeight !== -1 ? \"\".concat(context.mode.allocatedHeight, \"px\") : \"100%\";\n    this._container.innerHTML = \"\";\n    //if (!ImageSources.raw) return;\n    try {\n      // 2. Build the HTML String for the Picture element\n      // We use a template literal to keep it clean\n      this._container.innerHTML = \"\\n                <picture style=\\\"width: \".concat(ImageWidth, \"; height: \").concat(ImageHeight, \"; display: block;\\\">\\n                    \").concat(AVIFSource.raw ? \"<source srcset=\\\"\".concat(AVIFSource.raw, \"\\\" type=\\\"image/avif\\\" alt=\\\"\").concat(AltText.raw, \"\\\">\") : \"\", \"\\n                    \").concat(WebPSource.raw ? \"<source srcset=\\\"\".concat(WebPSource.raw, \"\\\" type=\\\"image/webp\\\" alt=\\\"\").concat(AltText.raw, \"\\\">\") : \"\", \"\\n                    <img \\n                        src=\\\"\").concat(JPEGSource.raw, \"\\\" \\n                        alt=\\\"\").concat(AltText.raw, \"\\\" \\n                        loading=\\\"lazy\\\" \\n                        style=\\\"width: 100%; height: 100%; object-fit: cover; display: block;\\\"\\n                    />\\n                </picture>\\n            \");\n      this._container.style.width = ImageWidth;\n      this._container.style.height = ImageHeight;\n    } catch (e) {\n      console.error(\"PowerImage Ultra-Light: JSON error\", e);\n    }\n  }\n  getOutputs() {\n    // No outputs required for this visual-only component control\n    return {};\n  }\n  destroy() {\n    // No cleanup needed for this stateless component control\n    // For native HTML elements, the browser handles the cleanup automatically when the DOM node is removed.\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PowerImageUltraLight/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./PowerImageUltraLight/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SunilP.PowerImageUltraLight', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerImageUltraLight);
} else {
	var SunilP = SunilP || {};
	SunilP.PowerImageUltraLight = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerImageUltraLight;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}