/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PowerImageUltraLight/index.ts"
/*!***************************************!*\
  !*** ./PowerImageUltraLight/index.ts ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PowerImageUltraLight: () => (/* binding */ PowerImageUltraLight)\n/* harmony export */ });\n// Define the priority ranking\nvar PRIORITY_MAP = {\n  'image/avif': 1,\n  'image/webp': 2,\n  'image/png': 3,\n  'image/jpeg': 4,\n  'image/gif': 5\n};\nclass PowerImageUltraLight {\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n  }\n  // Helper to get image type from URL extension\n  getMimeType(url) {\n    var _a;\n    var extension = (_a = url.split('.').pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase();\n    switch (extension) {\n      case 'avif':\n        return 'image/avif';\n      case 'webp':\n        return 'image/webp';\n      case 'png':\n        return 'image/png';\n      case 'gif':\n        return 'image/gif';\n      default:\n        return 'image/jpeg';\n    }\n  }\n  updateView(context) {\n    var {\n      ImageSources,\n      AltText,\n      Sizes,\n      ImageWidth,\n      ImageHeight\n    } = context.parameters;\n    this._container.innerHTML = \"\";\n    if (!ImageSources.raw) return;\n    try {\n      var rawUrls = JSON.parse(ImageSources.raw);\n      if (rawUrls.length === 0) return;\n      // 1. Map URLs to their types and ranks / Sort by performance priority\n      var sortedSources = rawUrls.map(url => ({\n        url: url,\n        type: this.getMimeType(url),\n        rank: PRIORITY_MAP[this.getMimeType(url)] || 99\n      })).sort((a, b) => a.rank - b.rank);\n      var picture = document.createElement(\"picture\");\n      // 2. Only create <source> tags for MODERN formats (Rank < 3: AVIF/WebP).\n      // Append <source> tags in the correct priority order (AVIF -> WebP -> JPG)\n      sortedSources.filter(src => src.rank < 3).forEach(src => {\n        var sourceTag = document.createElement(\"source\");\n        sourceTag.srcset = src.url;\n        sourceTag.type = src.type;\n        // This satisfies: \"the sizes attribute reduces the number of pixels downloaded\"\n        if (Sizes.raw) sourceTag.sizes = Sizes.raw;\n        picture.appendChild(sourceTag);\n      });\n      // 3. Find the best legacy fallback for the <img> tag (Rank >= 3: JPG/PNG)\n      var fallback = sortedSources.find(s => s.rank >= 3) || sortedSources[0];\n      // The safety net that completes the 'Ultra-Light' strategy\n      var img = document.createElement(\"img\");\n      img.src = fallback.url;\n      img.alt = AltText.raw || \"\";\n      img.loading = \"lazy\";\n      // Apply dynamic sizing, Explicitly apply the styles from your inputs\n      img.style.width = ImageWidth.raw || \"100%\";\n      img.style.height = ImageHeight.raw || \"auto\";\n      img.style.objectFit = \"cover\";\n      picture.appendChild(img);\n      this._container.appendChild(picture);\n    } catch (e) {\n      console.error(\"PowerImage Ultra-Light: JSON error\", e);\n    }\n  }\n  getOutputs() {\n    // No outputs required for this visual-only component control\n    return {};\n  }\n  destroy() {\n    // No cleanup needed for this stateless component control\n    // For native HTML elements, the browser handles the cleanup automatically when the DOM node is removed.\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PowerImageUltraLight/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./PowerImageUltraLight/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SunilP.PowerImageUltraLight', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerImageUltraLight);
} else {
	var SunilP = SunilP || {};
	SunilP.PowerImageUltraLight = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerImageUltraLight;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}